#init function here

def function() :
    pass